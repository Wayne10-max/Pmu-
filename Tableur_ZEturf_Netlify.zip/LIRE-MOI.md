# Tableur ZEturf — Netlify

Version préparée le 17 octobre 2026 pour le projet scintillating-starlight-92c72.

Ce dossier contient l'application de répétitions avec ZEturf.fr comme seule source, le relais Netlify, une page de diagnostic et une copie de l'ancienne application. Le relais ne place aucun pari et n'utilise aucun compte ZEturf.

## Interface compacte et actualisation

- Thème clair gris, blanc et bleu, textes plus petits.
- Menu Réunion : numéro R, hippodrome, pays et nombre de courses. Le filtre porte sur les sélections, les noms, les exemples et le bilan. Le CSV du jour reste complet ; le rapport suit la réunion choisie.
- Actualisation sans vider les données ; position dans la course et détails ouverts conservés.
- Six lectures simultanées, premiers résultats affichés par lots, calculs inchangés réutilisés. Les arrivées officielles sont revérifiées après au plus 30 minutes ; les autres courses sont relues à chaque actualisation.

## Ce qui fonctionne dans cette version

- Lecture automatique du programme français ZEturf du jour à l'ouverture, puis toutes les cinq minutes si la page reste visible.
- Extraction des codes R/C ZEturf, prix, noms des chevaux, numéros, jockeys/drivers et horaires en heure de Paris.
- Courses françaises et étrangères du programme ZEturf.fr. Les pages explicitement PMH ou sans marché simple gagnant identifiable sont exclues. Les non-partants sont conservés dans le CSV et exclus du scan.
- Protocoles avec et sans jour, matrice du fichier initial, répétitions et exports CSV / HTML.
- Arrivées comptées uniquement quand la page porte une arrivée officielle et que le gagnant a été extrait.
- Archives et réglages locaux séparés des anciennes données PMU.

Le nom brut et le nom testé sont toujours visibles. Les noms de famille qui restent ambigus sont exclus des phrases jockey jusqu'à correction dans l'interface. Les initiales placées après un nom de famille sont retirées, par exemple « Charron J. » devient « charron ».

Le chargement en ligne est limité au jour courant. Les dates précédentes se consultent via les sauvegardes JSON, les CSV et l'historique local enregistrés à ces dates.

## Déploiement dans ton projet existant

Il faut un déploiement avec construction des fonctions : un simple dépôt sur Netlify Drop ne compile pas les fonctions serveur.

### Avec le dépôt GitHub déjà lié à Netlify

1. Décompresser l'archive.
2. Ajouter son contenu à la racine du dépôt `Wayne10-max/Pmu-` : `netlify.toml`, `package.json`, `package-lock.json`, les dossiers `public`, `netlify` et `lib`. Les fichiers de tests sont facultatifs pour le déploiement, mais recommandés pour vérifier le projet.
3. Dans Netlify, conserver le répertoire de base à la racine du dépôt et lancer un déploiement de la branche de production. Le fichier `netlify.toml` définit `public` comme dossier publié et `netlify/functions` comme dossier des fonctions.
4. Ouvrir le site. Le chargement ZEturf démarre automatiquement. L'ancienne interface reste accessible par `ancienne-application.html`.
5. Ouvrir `test-zeturf.html` pour vérifier depuis Netlify l'accès au programme, puis sélectionner une course et comparer ses partants à ZEturf.fr.

### Avec un ordinateur et le CLI Netlify

Dans le dossier décompressé, avec Node.js 20.18.1 ou plus récent :

```sh
npm ci
npm test
npx netlify-cli login
npx netlify-cli link
npx netlify-cli deploy --build
```

Sélectionner le projet existant `scintillating-starlight-92c72` lors du lien. La première commande de déploiement crée un aperçu pour vérification. Une fois cet aperçu vérifié :

```sh
npx netlify-cli deploy --build --prod
```

## Vérifications effectuées avant livraison

Les calculs reprennent les matrices du fichier initial. Le relais, le parseur et l'intégration sont testés automatiquement : domaines autorisés, refus d'origine, redirections, délais, contenus inattendus, refus géographique, erreurs HTTP, dédoublonnage, codes et dates de course incohérents, lecture des partants, non-partants, résultat officiel et aller-retour CSV.

Des pages publiques ZEturf de Belmont Park, Wolvega et Auteuil du 17 octobre 2026 ont été reçues en HTTP 200 et comparées aux extractions. Les fixtures de test ne conservent que les champs factuels nécessaires.

La connexion depuis l'environnement Netlify du compte doit encore être vérifiée après publication. Un succès depuis l'environnement de préparation ne garantit pas l'accès depuis Netlify. Si ZEturf demande une vérification humaine ou refuse une localisation, le relais affiche ce refus et s'arrête ; il ne contourne pas la restriction.

## Repères techniques

- Application : `public/index.html`, un seul HTML avec CSS et JavaScript intégrés.
- Diagnostic : `public/test-zeturf.html`.
- Ancienne application : `public/ancienne-application.html`.
- Relais : `netlify/functions/zeturf.mjs`.
- Extraction : `lib/zeturf-parser.mjs` ; dépendance Cheerio verrouillée dans `package-lock.json`.
- Le relais est limité à la lecture GET des pages publiques HTTPS de ZEturf.fr. Aucun cookie, identifiant ou mot de passe utilisateur n'est transmis.
- Toutes les phrases communes à une course sont hors classement des chevaux. Les répétitions ne sont pas une probabilité de victoire.

Documentation officielle : https://docs.netlify.com/build/functions/get-started/
