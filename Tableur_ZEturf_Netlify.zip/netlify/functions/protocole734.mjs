import {load} from 'cheerio';
import {readPublicPage,validateTarget,RelayError} from './zeturf.mjs';
import {parseCourse} from '../../lib/zeturf-parser.mjs';
const clean=s=>String(s??'').replace(/\s+/g,' ').trim();
function amount(s){s=clean(s);if(!s)return null;if(/rembours/i.test(s))return 100;const n=Number(s.replace(/[^\d,.-]/g,'').replace(',','.'));return Number.isFinite(n)&&n>=0?Math.round(n*100):null;}
export function readReports(html){const $=load(html),table=$('#rapports [data-turbo-stream-id="rapports-table--10"]'),heads=table.find('.table-header').last().children('.table-cell').map((_,e)=>clean($(e).text())).get(),g=heads.indexOf('Simple gagnant'),p=heads.indexOf('Simple placé'),sg={},sp={};table.find('.table-body > .table-row').each((_,e)=>{const cells=$(e).children('.table-cell').map((_,c)=>clean($(c).text())).get(),num=Number(cells[0]);if(!Number.isInteger(num)||num<1)return;for(const [index,dest] of [[g,sg],[p,sp]])if(index>0){const a=amount(cells[index]);if(a!==null)dest[num]=a;}});return {baseEuros:1,available:Object.keys(sg).length>0&&Object.keys(sp).length>0,gagnantCents:sg,placeCents:sp};}
function json(data,status=200){return new Response(status===204?null:JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','access-control-allow-origin':'*','access-control-allow-methods':'GET, OPTIONS','access-control-max-age':'86400','cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'no-referrer'}});}
export function createHandler(fetchImpl=fetch,clock=()=>Date.now()){
 const cache=new Map(),inflight=new Map();
 return async request=>{
  if(request.method==='OPTIONS')return json({},204);
  if(request.method!=='GET')return json({ok:false,code:'method_not_allowed',message:'Seule la lecture des courses est disponible.'},405);
  try{
   const q=new URL(request.url),target=validateTarget(q.searchParams.get('url')||undefined),isCourse=/\/course-du-jour\//.test(target.pathname),key=target.href;
   let entry=cache.get(key);
   if(!entry||clock()-entry.at>90000){
    if(!inflight.has(key))inflight.set(key,(async()=>{const page=await readPublicPage(key,fetchImpl),capturedAt=new Date(clock()).toISOString();let payload;if(isCourse){const course=parseCourse(page.html,page.sourceURL);const $=load(page.html);if(/course annul[eé]e|[eé]preuve annul[eé]e/i.test(clean($('#course-header').text())))course.statut='ANNULEE';course.rapports=readReports(page.html);payload={course,courseLinks:page.courseLinks};}else payload={courseLinks:page.courseLinks,title:page.title};const item={at:clock(),data:{ok:true,source:'ZEturf.fr',capturedAt,...payload}};cache.set(key,item);while(cache.size>160)cache.delete(cache.keys().next().value);return item;})().finally(()=>inflight.delete(key)));
    entry=await inflight.get(key);
   }
   return json({...entry.data,servedAt:new Date(clock()).toISOString()});
  }catch(e){const expected=e instanceof RelayError||e.status===422;return json({ok:false,code:expected?e.code:'network_error',message:expected?e.message:'Le chargement ZEturf est momentanément impossible. Réessaie dans quelques instants.'},expected?(e.status||502):502);}
 };
}
export default createHandler();
