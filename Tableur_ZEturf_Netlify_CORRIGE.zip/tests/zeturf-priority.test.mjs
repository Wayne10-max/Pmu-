import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';

const source=await readFile(new URL('../public/analyse-hippique.html',import.meta.url),'utf8');
const script=source.split('<script>')[1]?.split('</script>')[0];
test('Mode approfondi activé aussi avec ZEturf',()=>{
 assert(script);
 assert(script.includes("if($('autoStaff').checked){"));
 assert(script.includes('zeEnsurePMU(date)'));
 assert(script.includes('zOnly:false,pmuLinked:true'));
 assert(source.includes('Mode approfondi : ZEturf en premier'));
});
test('ZEturf conserve ses valeurs et PMU complète seulement les trous',()=>{
 const a=script.indexOf('function zeMergeFallback('),b=script.indexOf('async function getRace(',a);
 assert(a>=0&&b>a);
 const context={norm:s=>String(s??'').toUpperCase().replace(/[^A-Z0-9]/g,'')};
 vm.createContext(context);vm.runInContext(script.slice(a,b)+';globalThis.merge=zeMergeFallback',context);
 const z={key:'Z',meeting:9,number:3,hippo:'Auteuil',course:'Prix Test',distance:3900,discipline:'HAIE',sourceNotes:[],parts:[{numPmu:1,nom:'CHEVAL TEST',driver:'JOCKEY Z',entraineur:'ENTRAINEUR Z',statut:'PARTANT'}]};
 const p={key:'P',meeting:1,number:3,hippo:'Auteuil',terrain:'LOU',parts:[{numPmu:1,nom:'CHEVAL TEST',driver:'JOCKEY P',entraineur:'ENTRAINEUR P',idCheval:11,statut:'NON_PARTANT'}]};
 const result=context.merge(z,p);
 assert.equal(result.parts[0].driver,'JOCKEY Z');
 assert.equal(result.parts[0].entraineur,'ENTRAINEUR Z');
 assert.equal(result.parts[0].idCheval,11);
 assert.equal(result.parts[0].statut,'NON_PARTANT');
 assert.equal(result.terrain,'LOU');
 assert.equal(result.key,'P');
 assert.equal(result.zOnly,false);
});
