import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const html=readFileSync(new URL('../public/analyse-hippique.html',import.meta.url),'utf8');
const js=html.split('<script>')[1].split('</script>')[0];
const slice=(a,b)=>js.slice(js.indexOf(a),js.indexOf(b,js.indexOf(a)));
const hCode=slice('function historicalPMU(p,row,context=S){','\nconst FEATURE_NAMES=');
const ctx={
 S:{},
 minusMonths:()=> '2025-10-01',months:()=>12,
 norm:s=>String(s||'').toUpperCase(),
 dateFR:d=>d.toISOString().slice(0,10),timeMS:()=>null,decodeShoes:()=>null,
 horseID:p=>p.idCheval,
 indexes:()=>({names:new Map()}),
 active:r=>r.parts,
 validDate:d=>/^\d{4}-\d{2}-\d{2}$/.test(d),
 relatedDiscipline:(a,b)=>a===b||(['HAIE','STEEPLECHASE'].includes(a)&&['HAIE','STEEPLECHASE'].includes(b)),
 safeRank:v=>Number.isInteger(Number(v))&&Number(v)>0?Number(v):0,
 knownOutcome:v=>v.p.ordreArrivee>0||/DISQUAL/i.test(v.p.incident||''),
 Number,Math,Object,Array,Date,Map,Set,
};
vm.createContext(ctx);
vm.runInContext(hCode+'\nglobalThis.getHist=historicalPMU;',ctx);
const horse={idCheval:'123',nom:'TEST'};
function race(d,dis,rank){return {raceDate:d,discipline:dis,raceName:'Prix '+d,raceRunParticipant:{horseName:'TEST',place:{runnerRank:String(rank),arrivalStatus:'PLACE'}}};}
const context=(races)=>({fullHistories:new Map([['123',{data:{runner:{racesRun:races}}}]]),sheets:new Map(),courses:new Map()});
const row={date:'2026-10-22',key:'R1C1',discipline:'HAIE'};
test('Le rang PMU transmis en chaîne est reconnu',()=>{const r=ctx.getHist(horse,row,context([race('2026-03-03','HAIE',2)]));assert.equal(r[0].p.ordreArrivee,2);});
test('Avec une seule sortie haies, deux sorties steeple connues peuvent compléter',()=>{const h=ctx.getHist(horse,row,context([race('2026-03-03','HAIE',2),race('2026-01-03','STEEPLECHASE',1),race('2025-12-03','STEEPLECHASE',4)]));assert.equal(h.length,3);assert.equal(h.filter(x=>x.r.discipline==='STEEPLECHASE').length,2);});
test('Avec trois résultats de haies, les sorties steeple ne sont pas ajoutées',()=>{const h=ctx.getHist(horse,row,context([race('2026-03-03','HAIE',2),race('2026-02-03','HAIE',1),race('2026-01-03','HAIE',4),race('2025-12-03','STEEPLECHASE',1)]));assert.equal(h.length,3);});
test('Les courses futures et d’une autre famille ne sont pas utilisées',()=>{const h=ctx.getHist(horse,row,context([race('2026-10-23','HAIE',1),race('2026-03-03','PLAT',2)]));assert.equal(h.length,0);});
