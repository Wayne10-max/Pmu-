import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
const page=await readFile(new URL('../public/analyse-hippique.html',import.meta.url),'utf8');
const source=page.split('<script>')[1].split('</script>')[0];
const code=source.slice(source.indexOf('function historicalCoverage(items){'),source.indexOf('\nfunction domain('));
const placeCode=source.slice(source.indexOf('function placeAnalysis(a){'),source.indexOf('\nfunction riskNotes('));
const context={
 MARGIN:.08,
 pct:n=>(100*n).toFixed(0)+'%',
 outcomeSample:(h,k)=>({n:h.length,hits:h.filter(v=>v.p.ordreArrivee<=k).length}),
 placeTerms:()=>({k:3,label:'3 places'}),
 smoothedPlace:(h,k)=>h.length?h.filter(v=>v.p.ordreArrivee<=k).length/h.length:null,
 Number,Math,Array
};
vm.createContext(context);
vm.runInContext(code+'\n'+placeCode+'\n globalThis.chooseFn=choose; globalThis.placeFn=placeAnalysis;',context);
function horse(i,count=5){
 const rank=i===1?1:4;
 const h=Array.from({length:count},()=>({p:{ordreArrivee:rank},r:{nbParticipants:11}}));
 return {p:{nom:'CHEVAL '+i,numPmu:i},m:{h,last:h.slice(0,5),dist:h,ground:h,pair:h},score:15-i,o:{value:8},prob:.1,ev:.1};
}
test('Un seul cheval sans historique sur 11 ne doit pas bloquer le gagnant',()=>{
 const items=Array.from({length:11},(_,i)=>horse(i+1,i===10?1:5));
 const r=context.chooseFn(items,'WINNER');
 assert.equal(r.coverage.documented.length,10);
 assert.equal(r.coverage.needed,9);
 assert.equal(r.coverage.missing.length,1);
 assert.equal(r.pick.p.numPmu,1);
 assert.ok(r.provisional);
});
test('Un seul cheval sans historique sur 11 ne doit pas bloquer le placé',()=>{
 const items=Array.from({length:11},(_,i)=>horse(i+1,i===10?1:5));
 const r=context.placeFn({row:{},items});
 assert.equal(r.coverage.documented.length,10);
 assert.equal(r.coverage.missing.length,1);
 assert.equal(r.pick.p.numPmu,1);
});
test('Peloton très incomplet : classement indicatif parmi chevaux connus',()=>{
 const items=Array.from({length:11},(_,i)=>horse(i+1,i>=8?1:5));
 assert.equal(context.chooseFn(items,'WINNER').coverage.documented.length,8);
 assert.equal(context.chooseFn(items,'WINNER').pick.p.numPmu,1);
 assert.equal(context.placeFn({row:{},items}).pick.p.numPmu,1);
});
test('Capture réelle simulée : 6 sur 10, les gagnant et placé s’affichent comme classement indicatif',()=>{
 const items=Array.from({length:10},(_,i)=>horse(i+1,i<6?5:i===6?0:2));
 const w=context.chooseFn(items,'WINNER'),p=context.placeFn({row:{},items});
 assert.equal(w.coverage.documented.length,6);
 assert.equal(w.coverage.partial,true);
 assert.equal(w.pick.p.numPmu,1);
 assert.equal(p.coverage.documented.length,6);
 assert.equal(p.pick.p.numPmu,1);
});
test('Un seul cheval documenté : conserver l’abstention',()=>{
 const items=Array.from({length:10},(_,i)=>horse(i+1,i===0?5:0));
 assert.equal(context.chooseFn(items,'WINNER').pick,null);
 assert.equal(context.placeFn({row:{},items}).pick,null);
});
test('Aucun historique exploitable : ne pas fabriquer de favori',()=>{
 const items=Array.from({length:11},(_,i)=>horse(i+1,0));
 assert.equal(context.chooseFn(items,'WINNER').coverage.documented.length,0);
 assert.equal(context.chooseFn(items,'WINNER').pick,null);
 assert.equal(context.placeFn({row:{},items}).pick,null);
});
