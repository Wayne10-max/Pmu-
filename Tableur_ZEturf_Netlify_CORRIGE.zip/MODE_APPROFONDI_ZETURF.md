# Gagnant & Placé — Mode approfondi ZEturf prioritaire

Page : `public/analyse-hippique.html`.
Relais : `netlify/functions/zeturf.mjs` + `lib/zeturf-parser.mjs`.

1. Charge d'abord le programme et les fiches de course chez ZEturf, y compris les chevaux, jockeys, entraîneurs présents, horaires, et autres champs effectivement exposés.
2. Si une fiche ZEturf manque, n'utilise PMU qu'après une correspondance unique contrôlée par le lien officiel de course et sa date.
3. Le format actuel du relais ZEturf n'expose pas les sorties historiques complètes. Pour ces informations, le programme recherche la correspondance PMU stricte (date, lieu, prix, discipline, distance, heure, TOUS les numéros et noms de partants) avant tout complément.
4. Si le rapprochement échoue, le programme n'invente aucune statistique ; la sélection peut donc s'abstenir.
5. En mode approfondi, après la lecture primaire ZEturf, l'application collecte en secours les 90 jours d'archives PMU nécessaires aux statistiques pour les disciplines rapprochées. Cette opération peut être très longue.
6. L'interface indique la provenance des données et ne promet pas de probabilité ou rentabilité garantie.
7. Le test rétrospectif reste fondé sur les archives PMU et ne mesure pas un modèle entièrement ZEturf.

## Publication dans le dépôt Wayne10-max/Pmu-
Remplacer, à la racine GitHub, l'archive **Tableur_ZEturf_Netlify_CORRIGE.zip** par celle fournie, en gardant exactement le même nom et la commande netlify.toml actuelle.
Vérifier ensuite le déploiement Netlify, et ouvrir : https://scintillating-starlight-92c72.netlify.app/analyse-hippique.html

ATTENTION : la disponibilité effective de l'API Netlify et l'extraction ZEturf dépendent de l'accès au site distant. Aucun test de connexion de bout en bout n'a pu être validé depuis le contexte de cette édition.
