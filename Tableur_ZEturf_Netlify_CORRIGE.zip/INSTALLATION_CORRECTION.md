# Correction du relais ZEturf

Le site en ligne n’a pas encore été modifié.

## Mise en place sur le projet GitHub relié à Netlify
1. Extraire cette archive.
2. Dans le dépôt GitHub lié au site, remplacer `netlify/functions/zeturf.mjs` par la version de cette archive. Ce fichier est en .mjs, pas en .js.
3. Ajouter `public/analyse-hippique.html`. Le tableur existant reste sur la page d’accueil.
4. Enregistrer les modifications sur la branche déployée et attendre le déploiement Netlify réussi.
5. Ouvrir https://scintillating-starlight-92c72.netlify.app/analyse-hippique.html puis Tester la connexion.

Ne pas déposer uniquement le dossier public avec Netlify Drop : les fonctions serveur nécessitent le déploiement du projet (Git ou CLI).

## Ce qui change
- Lecture depuis un fichier HTML local (Origin null), sans cookies ni identifiants. Les autres origines restent refusées.
- Réponses OPTIONS, GET et erreurs cohérentes.
- Cache en mémoire de 15 secondes, 8 pages maximum, et regroupement des requêtes identiques en cours. L’horodatage indique la récupération réelle.
- Nouvelle page d’analyse gagnant / placé, sans remplacement du tableur de répétitions.

## Limites
Le correctif ne crée pas d’historiques, de cotes ni de statistiques absentes de ZEturf. Les analyses utilisent les compléments PMU vérifiés ou s’abstiennent. La vitesse réelle dépend du site source et de Netlify. Le cache est propre à chaque instance serveur.
