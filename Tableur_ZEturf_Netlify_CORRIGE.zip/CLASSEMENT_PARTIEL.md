# Correction de l’abstention systématique

Cette version conserve ZEturf comme source principale et PMU seulement en secours contrôlé.

- Dès que 2 chevaux ont chacun au moins 3 résultats connus, affichage d’un **classement indicatif parmi ces chevaux**.
- Les chevaux avec moins de 3 résultats ne sont jamais classés et peuvent pourtant gagner ou se placer.
- En cas d’égalité, affiche les deux candidats très proches.
- Si moins de 2 chevaux sont documentés, abstention motivée : pas de prédiction inventée.
- Pour les haies, steeple-chase et cross, les archives d’une autre spécialité sont des informations secondaires utilisées uniquement si moins de 3 résultats connus dans la spécialité du jour.
- Les rangs numériques au format texte dans certaines réponses PMU sont reconnus.
- Ne confonds pas premier dans les données reçues et favori fiable de tout le peloton.

Publier `Tableur_ZEturf_Netlify_CORRIGE.zip` via GitHub ; attendre Published dans Netlify et ouvrir `/analyse-hippique.html` directement en ligne.
